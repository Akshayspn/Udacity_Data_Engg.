                                        
                                        
 #                                      Sparkify: AWS S3 Data Lake
                                        
### 1. Purpose of this datalake in context of the startup, Sparkify, and their analytical goals.
The startup want to collect data from various sources in the json format and wants to  create a star schema optimized for queries on song play analysis. The main goal of the startup is to get an insights on how the users liking the songs, attributse of most liked songs etc.This star schema will enable sparkify to realise their goals in a performant manner.

### 2. State and justify your database schema design and ETL pipeline.
The dimensions songs , users, time are created from the raw files that are received from various sources. The above dimensions are joined together to create a fact table song_plays which acts as the centralised fact table containing various facts related to the songs played by the users.

### 3.Provide example queries and results for song play analysis.
Provided in the Analysis.py code and results are printed on the output console of Master.ipynb file
       
### 4. How to Run:
  Step1. Update your AWS Access keys in the dl.cfg file.
  
  Step2: Provide your output AWS S3 storage location at line 182 in the etl.py file.US-West2 is the preferred region for            output bucket creation for faster read and write.
  
  Step3: Execute Master.ipynb notebook
  
  Step4. Analyse the results printed on the notebook output console.
    
### 5. Description of Files in the project  
  1.Analysis.py : It contains the count queries from the facts and the dimension tables directly from S3 data lake.
  
  2.etl.py : It fetches raw files, clean up them and perform load in the S3 bucket in the parquet format.
  
  3.Master.py: It contains the calling modules for the etl.py and Analysis.py. This prints up the results of each step for quick analysis and status update of the Data lake preparation.
  
  4.dl.cfg: It contains the AWS access keys for the user.