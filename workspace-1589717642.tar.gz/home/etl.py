""" This module deals with the ETL processing of the JSON files and Log files and finally prepares the data lake in S3 by storing files in a Parquet format.
"""

"""Importing necessary libraries."""
import configparser
from datetime import datetime
import os
from pyspark.sql import SparkSession
from pyspark import SparkConf
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.functions import udf, col
from pyspark.sql.functions import year, month, dayofmonth, hour, weekofyear, date_format
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.types import StructType as S, StructField as SF, DoubleType as Dbl, StringType as Str, IntegerType as Int, DateType as Dat, TimestampType

#Setting Enviornment variables
config = configparser.ConfigParser()
config.read('dl.cfg')
os.environ['AWS_ACCESS_KEY_ID']=config['AWS_CREDS']['AWS_ACCESS_KEY_ID']
os.environ['AWS_SECRET_ACCESS_KEY']=config['AWS_CREDS']['AWS_SECRET_ACCESS_KEY']

"""
This function accept datetime and returns it into datetime format.
"""
def format_datetime(ts):
        return datetime.fromtimestamp(ts/1000.0)

"""Function to create spark session with optimal settings for faster execution/processing in spark.Below Settings are indicative in nature and may need to be altered if there is change in the source data. 
"""
def create_spark_session():
    conf=SparkConf()
    conf.set("spark.executor.memory", "4g")
    conf.set("spark.driver.memory", "4g")
    conf.set("spark.cores.max", "2")
    conf.set("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.5")
    conf.set("spark.executor.instances", "4")
    conf.set("spark.sql.autoBroadcastJoinThreshold","-1")
    conf.set("spark.sql.broadcastTimeout","1000")
    sc = SparkContext.getOrCreate(conf)
    spark = SQLContext(sc)
    return spark



"""
This function extracts raw JSON song files and transforms and load 
Song data file to create song table and artist table on S3.

spark: It indicates the spark session
input_data: S3 path where the source files are residing.
Output_data: S3 path where the output parquet format tables are written
"""
def process_song_data(spark, input_data, output_data):
    # get filepath to song data file
       
    song_data = input_data + 'song_data/*/*/*/*.json'
    
    # read song data file by defining schema
    songSchema = S([
        SF("artist_id",Str()),
        SF("artist_latitude",Dbl()),
        SF("artist_location",Str()),
        SF("artist_longitude",Dbl()),
        SF("artist_name",Str()),
        SF("duration",Dbl()),
        SF("num_songs",Int()),
        SF("title",Str()),
        SF("year",Int()),
    ])
    print("song data read starting...")
    df = spark.read.json(song_data, schema=songSchema)
    print("song data read completed successfully.")

    # extract columns to create songs table
    songs_table = df.select('title', 'artist_id', 'year', 'duration').dropDuplicates()\
                    .withColumn("song_id", monotonically_increasing_id()).cache()
    
        extract columns to create artists table
    artists_table = df.select('artist_id','artist_name','artist_location','artist_latitude','artist_longitude')\
                      .withColumnRenamed("artist_name","name")\
                      .withColumnRenamed("artist_location","location")\
                      .withColumnRenamed("artist_latitude","latitude")\
                      .withColumnRenamed("artist_longitude","longitude").dropDuplicates().cache()
    
    print("Writing artist_table data to S3 .")
    # write artists and song table to parquet files and save them on S3 bucket
    artists_table.write.mode('overwrite').parquet(output_data+'/artists_table')
    print("artist_table data write completed successfully.")
   # write songs table to parquet files partitioned by year and artist
    print("Writing songs_table data to S3 .")
    songs_table.write.mode('overwrite').partitionBy("year","artist_id").parquet(output_data+'/songs_table')
    print("song data write completed successfully.")
    
    print("song data process function completed successfully....")

"""
This function to process the log files and join the songs, artist and time dimensions to create fact song_plays file which is saved on S3 server in a parquet format.

spark: It indicates the spark session
input_data: S3 path where the source files are residing.
Output_data: S3 path where the output parquet format tables are written
"""
    #Process Log data function
def process_log_data(spark, input_data, output_data):
    # get filepath to log data file
    log_data =input_data + 'log_data/*/*/*.json'
   
    # read log data file
    df_log = spark.read.json(log_data)
    print("log data read completed successfully.")

    # filter by actions for song plays
    df_log = df_log.filter(df_log.page == 'NextSong')
    print("log data filtered successfully.")
    
    # extract columns for users table    
    users_table = df_log.select('userId','firstName','lastName','gender','level')\
                    .withColumnRenamed("userId","user_id")\
                    .withColumnRenamed("firstName",'first_name')\
                    .withColumnRenamed("lastName","last_name").dropDuplicates().cache()
    
      # create timestamp column from original timestamp column
    get_timestamp = udf(lambda x: format_datetime(int(x)),TimestampType())
    df_log = df_log.withColumn("start_time1", get_timestamp(df_log.ts))
    
   
    # extract columns to create time table
    time_table  = df_log.select("start_time1").dropDuplicates()\
                    .withColumn("hour", hour(col("start_time1")))\
                    .withColumn("day", dayofmonth(col("start_time1")))\
                    .withColumn("week", weekofyear(col("start_time1")))\
                    .withColumn("month",month(col("start_time1")))\
                    .withColumn("year",year(col("start_time1")))\
                    .withColumn("weekday",date_format(col("start_time1"), 'E')).dropDuplicates()
    #rename Column in time table to avoid name conflict during join
    time_table=time_table.withColumnRenamed("start_time1","start_time").cache()
      
    # read in song data to use for songplays table
    song_df = spark.read.parquet(output_data + 'songs_table').dropDuplicates().cache()
    print("song_df data read completed successfully.")
    
    # read in artist data to use for songplays table
    df_artists = spark.read.parquet(output_data+'artists_table').dropDuplicates().cache()
    print("df_artists data read completed successfully.")

    #Starting join operations ..
    print("Starting Join operations now......")
    # Rename Cols artist_id to artist_id1 and year to year1 from artist table to avoid name conflict in artist and time  #table while saving results
    df1=df_log.join(song_df, (df_log.song == song_df.title)).withColumnRenamed("artist_id","artist_id1")\
                                                            .withColumnRenamed("year","year1").dropDuplicates().cache()
    print("First Join of log and song data completed..")
    # Rename location column to avoid conflict with artist location data and log  location data
    df_artists=df_artists.withColumnRenamed("location","location1").dropDuplicates().cache()
    #Join with artist table
    df2=df1.join(df_artists,(df1.artist_id1 == df_artists.name)).dropDuplicates().cache()
    print("Second Join of df and artist data completed..")
    #Join with time table
    df3=df2.join(time_table, (df2.start_time1 == time_table.start_time), 'left').dropDuplicates().cache()
    print("Third Join of df and time data completed..")
    
    print("Creating fact songplays now....")
    #Create Songplays table.
    songplays_table=df3.select(col('start_time').alias('start_time'),\
                    col('userId').alias('user_id'),\
                    col('level').alias('level'),
                    col('song_id').alias('song_id'),
                    col('artist_id').alias('artist_id'),
                    col('sessionId').alias('session_id'),
                    col('location').alias('location'),
                    col('userAgent').alias('user_agent'),
                    col('year').alias('year'),
                    col('month').alias('month'),
                    ).repartition("year", "month").dropDuplicates().cache()
    
    ######################Saving results /dataframes to S3#################
    
    # write songplays table to parquet files partitioned by year and month
    songplays_table.write.mode('overwrite').parquet(output_data+'/songplays_table')
    print("songplays_table data write completed successfully.")
    
      # write users table to parquet files
    users_table.write.parquet(output_data+'/users_table',mode="overwrite")
    print("user_table data write completed successfully.")
    
      # write time table to parquet files partitioned by year and month
    time_table.write.mode('overwrite').parquet(output_data+'/time_table')
    print("time data write completed successfully.")
  
    print("Log data process function completed successfully....")
    
"""
    This is the main function of etl.py and is the entry point of the etl processing.
    Note:
    Output_data is the S3 path which needs to be created on the S3 server.
"""
def main():
    spark = create_spark_session()
    input_data = "s3a://udacity-dend/"
    output_data = "s3a://project4-udacity/"
    
    process_song_data(spark, input_data, output_data)    
    process_log_data(spark, input_data, output_data)

if __name__ == "__main__":
    main()
