""" This module deals with the count validation of the various tables that are created and stored on the S3 server in a parquet."""

"""Importing necessary libraries."""
import configparser
import os
from pyspark.sql import SparkSession

#Setting Enviornment variables
config = configparser.ConfigParser()
config.read('dl.cfg')
os.environ['AWS_ACCESS_KEY_ID']=config['AWS_CREDS']['AWS_ACCESS_KEY_ID']
os.environ['AWS_SECRET_ACCESS_KEY']=config['AWS_CREDS']['AWS_SECRET_ACCESS_KEY']


"""
 Function to create spark session with optimal settings for faster execution.
"""
def create_spark_session():
    spark = SparkSession \
        .builder \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.5") \
        .getOrCreate()
    return spark

"""
This function performs validation of count from given tables.
Spark: Spark session variable
output_data: S3 path where the datalake files are stored in a parquet format.
"""

def Count_validation(spark, output_data):
       
    # Read in song data and calculate count of it.
    print("Begining Data count validation now.. .")
    print("songs_table data count is .")
    song_df = spark.read.parquet(output_data + 'songs_table')
    print(song_df.count())
    
    # Read in artist data and calculate count of it.
    print("artists_table data count is .")
    df_artists = spark.read.parquet(output_data+'artists_table')
    print(df_artists.count())
 
    
     # Read in user data and calculate count of it.
    print("users_table data data count is .")
    users_table = spark.read.parquet(output_data+'users_table')
    print(users_table.count()) 
    
    # Read in time data and calculate count of it. 
    print("time_table data count is.")
    time_table = spark.read.parquet(output_data+'time_table')
    print(time_table.count()) 
        
    # eRead in songplays  data and calculate count of it.
    print("songplays_table data count is  .")
    df_songplays_table = spark.read.parquet(output_data+'songplays_table')
    print(df_songplays_table.count()) 
    print("data count Validation completed successfully.")

    """This is the driver function of the analysis module and acts as an entry point of this program."""
def main():
    spark = create_spark_session()
    output_data = "s3a://project4-udacity/"
    Count_validation(spark,  output_data)
if __name__ == "__main__":
    main()
