#Import necessary libraries
import configparser
import psycopg2
from sql_queries import create_table_queries, drop_table_queries

#Drop the tables if existing 
def drop_tables(cur, conn):
    for query in drop_table_queries:
        print("Executing"+query)
        cur.execute(query)
        conn.commit()

#Create the tables 
def create_tables(cur, conn):
    for query in create_table_queries:
        print("Executing"+query)
        cur.execute(query)
        conn.commit()

#Main function
def main():
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    conn = psycopg2.connect("host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values()))
    print('Connected to the cluster')
    cur = conn.cursor()
    
    drop_tables(cur, conn)
    create_tables(cur, conn)
    print('Tables has been recreated successfully')
    conn.close()
    


if __name__ == "__main__":
    main()