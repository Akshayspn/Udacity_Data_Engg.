# Summary of the project

The project implements datawarehouse of company sparkify where it extracts raw data in json format from S3 bucket and loads into the Redshift database.
The redshift Database cluster has been configured directly through AWS Console. Once the Staging data gets loaded correctly, it is then used to load the facts and the dimension tables to implement star schema of the Datawarehouse.Finally, Validation of tables is performed by fetching count of records loaded in each table.




# How to run the Python scripts

Step1. Configure and launch AWS redshift cluster. Get AWS access keys and AWS secret Key to avoid facing the IAM user access issue ( connection issue comes sometimes when we implement connection through ARN or our cluster is in different region than S3 buckets region). Also notedown various details of cluster e.g. Port. no., endpoint connection URL etc. and poplate them in dwh.cfg file.

Step2. Supply Your Access Key and Id at line 118 and 125 in place of XXX for authentication with AWS cluster.

Step3.You are now ready to run the ETL process. Go to Master.ipynb file and run the Cell one after the other.

Step4. Notice the progress stages of the ETL process through the cell outputs.

Step5. You will receive the message "Validation completed successfully when all tables gets loaded correctly." 

Step6. You are done. 



# Explanation of the files in the repository.

1. dwh.cfg : It contains the cluster and S3 file location details.
2. sql_queries.py: It contains table creation, loading and drop queries.
3. README.md: It is the documetation file of project.
4. etl.py: It contains the etl functions which loads the data to staging layer and FACTS and DIM tables. 
5. Master.ipynb : It is a wrapper file which call the each function as an standalone entity.
6. create_table.py :  It drops and creates the tables in the staging and the final layer in Redshift by calling drop and create functions.
7. Analysis_Validation.py : It fetched the count of all tables and print then to console through cursor.

