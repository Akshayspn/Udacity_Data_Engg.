#Import necessary libraries
import configparser
import psycopg2
from sql_queries import copy_table_queries, insert_table_queries


#This function performs staging load by loading data from S3 to Redshift staging layer
def load_staging_tables(cur, conn):
    for query in copy_table_queries:
        print("Executing"+query)
        cur.execute(query)
        conn.commit()

#This function load Dimensions and fact tables from the staging tables
def insert_tables(cur, conn):
    for query in insert_table_queries:
        print("Executing"+query)
        cur.execute(query)
        conn.commit()

#Main Function
def main():
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    conn = psycopg2.connect("host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values()))
    cur = conn.cursor()
    print('Connected to the cluster. Begining ETL proces...Hold Tight..')   
    load_staging_tables(cur, conn)
    print('Staging load Completed now....Still Hold Tight as Dimension and Fact load will begin now..') 
    insert_tables(cur, conn)
    print('Fact & Dimension load Completed now....Relax!!.') 

    conn.close()


if __name__ == "__main__":
    main()