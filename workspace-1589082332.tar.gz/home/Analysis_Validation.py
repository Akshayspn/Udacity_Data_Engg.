#"""This Function Performs count validation for all the tables."""
import configparser
import psycopg2
from sql_queries import get_count_queries

#Fetch Count of rows in a table
def Query_tables(cur, conn):
    for query in get_count_queries:
        print("Executing"+query)
        cur.execute(query)
        print("Count in database is"+str(cur.fetchone()))
        conn.commit()
        
        
def main():
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    conn = psycopg2.connect("host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values()))
    cur = conn.cursor()
    print('Connected successfully to the cluster!!! Validating Tables count now.')   
    Query_tables(cur, conn)
    print('Validation Completed .Enjoy!!!.') 
    conn.close()

if __name__ == "__main__":
    main()